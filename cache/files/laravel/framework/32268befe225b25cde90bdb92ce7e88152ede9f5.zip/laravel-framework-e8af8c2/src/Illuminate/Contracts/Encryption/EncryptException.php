<?php

namespace Illuminate\Contracts\Encryption;

use RuntimeException;

class EncryptException extends RuntimeException
{
    //
}
